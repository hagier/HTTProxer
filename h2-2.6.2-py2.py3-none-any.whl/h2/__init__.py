# -*- coding: utf-8 -*-
"""
h2
~~

A HTTP/2 implementation.
"""
__version__ = '2.6.2'
